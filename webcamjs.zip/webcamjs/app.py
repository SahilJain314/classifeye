from flask import Flask, render_template, request, jsonify
import os
from werkzeug import secure_filename
from io import BytesIO
import re, time, base64
from PIL import Image

app = Flask(__name__)


def getI420FromBase64(codec, image_path="c:\\"):
    base64_data = re.sub('^data:image/.+;base64,', '', codec)
    byte_data = base64.b64decode(base64_data)
    image_data = BytesIO(byte_data)
    img = Image.open(image_data)
    t = time.time()
    img.save(image_path + str(t) + '.png', "PNG")

@app.route('/signup', methods=['GET','POST'])
def signup():
    if request.method == 'POST':
        codec = request.form['file']
        getI420FromBase64(codec)

    return render_template('classifeye.html')